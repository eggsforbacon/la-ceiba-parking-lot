package model;

/**
 * This are all the categories of stay time within the app. <br>
 */
public enum StayTime {
    HORA, DIA, MES, INDEFINIDO
}

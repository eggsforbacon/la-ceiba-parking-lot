package model;

/**
 * All the types of vehicles the parking lot can host. <br>
 */
public enum VehicleType {
    AUTOMOVIL, MOTO, CAMION, BUS, FURGON, CAMIONETA
}

package ui;

public interface ColorsOrWhatever {
    String BLACK = "#000000";
    String WHITE = "#FFFFFF";
    String GRAY = "#858585";
    String RED = "#EB2D2D";
    String BLUE = "#1B479E";
    String LIGHT_BLUE = "#38BCE8";
    String YELLOW = "#F7C716";
    String ORANGE = "#F5A00F";
    String GREEN = "#388A0C";
    String PINK = "#E354F0";
    String PURPLE = "#A13BEB";
    String BROWN = "#6B502E";
    String BEIGE = "#B39F79";
    String OTHER = "#63EBC0";
}
